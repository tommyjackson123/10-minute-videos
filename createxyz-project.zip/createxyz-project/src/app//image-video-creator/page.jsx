"use client";
import React from "react";

import { useUpload } from "../utilities/runtime-helpers";

function MainComponent() {
  const [image, setImage] = useState(null);
  const [video, setVideo] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [taskId, setTaskId] = useState(null);
  const [progress, setProgress] = useState(0);
  const [upload, { loading: uploadLoading }] = useUpload();

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setError(null);

    try {
      const { url, error } = await upload({ file });
      if (error) throw new Error(error);
      setImage(url);
    } catch (err) {
      console.error(err);
      setError("Failed to upload image: " + err.message);
    }
  };

  const checkVideoStatus = useCallback(async () => {
    if (!taskId) return;

    try {
      const response = await fetch("/api/check-video-status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId }),
      });

      if (!response.ok) {
        throw new Error(`Failed to check video status: ${response.status}`);
      }

      const data = await response.json();

      if (!data) {
        throw new Error("No response data received");
      }

      if (data.error) {
        throw new Error(data.error);
      }

      if (typeof data.progress === "number") {
        setProgress(data.progress);
      }
      if (data.videoUrl) {
        setVideo(data.videoUrl);
      }

      if (data.status === "completed") {
        setLoading(false);
        setTaskId(null);
      } else if (data.status === "processing") {
        setTimeout(checkVideoStatus, 3000);
      } else if (data.status === "failed") {
        throw new Error(data.error || "Video generation failed");
      }
    } catch (err) {
      console.error("Error checking status:", err);
      setError(err.message || "Failed to check video status");
      setLoading(false);
      setTaskId(null);
    }
  }, [taskId]);

  const generateVideo = async () => {
    if (!image) return;
    setLoading(true);
    setError(null);
    setVideo(null);
    setProgress(0);

    try {
      const response = await fetch("/api/generate-video", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageUrl: image }),
      });

      if (!response.ok) {
        throw new Error(`Failed to generate video: ${response.status}`);
      }

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      if (!data.taskId) {
        throw new Error("No task ID received from server");
      }

      setTaskId(data.taskId);
      setTimeout(checkVideoStatus, 1000);
    } catch (err) {
      console.error("Error generating video:", err);
      setError(err.message || "Failed to generate video");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-4 flex flex-col items-center">
      <h1 className="text-2xl font-bold mb-6">10-Minute Video Creator</h1>

      <div className="w-full max-w-md space-y-4">
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
          <input
            type="file"
            accept="image/*"
            onChange={handleImageUpload}
            className="hidden"
            id="imageUpload"
          />
          <label
            htmlFor="imageUpload"
            className="cursor-pointer block p-4 hover:bg-gray-50"
          >
            {uploadLoading ? (
              <p>Uploading image...</p>
            ) : image ? (
              <img
                src={image}
                alt="Uploaded"
                className="max-w-full h-auto mx-auto"
              />
            ) : (
              <p>Click to upload an image</p>
            )}
          </label>
        </div>

        <button
          onClick={generateVideo}
          disabled={!image || loading}
          className="w-full bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          {loading ? `Creating video... ${progress}%` : "Create Video"}
        </button>

        {error && (
          <div className="text-red-500 text-center p-4 bg-red-50 rounded-lg">
            <p className="font-semibold">Error:</p>
            <p>{error}</p>
          </div>
        )}

        {loading && (
          <div className="w-full bg-gray-200 rounded-full h-2.5">
            <div
              className="bg-blue-600 h-2.5 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        )}

        {video && (
          <div className="mt-4">
            <h2 className="text-lg font-semibold mb-2">Generated Video:</h2>
            <video controls className="w-full rounded-lg">
              <source src={video} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        )}
      </div>
    </div>
  );
}

export default MainComponent;