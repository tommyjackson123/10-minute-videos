async function handler({ imageUrl }) {
  if (!imageUrl) {
    return { error: "Image URL is required" };
  }

  console.log("Starting video generation with image:", imageUrl);

  try {
    // Generate a unique task ID
    const taskId = Date.now().toString();
    console.log("Generated task ID:", taskId);

    // Initialize global state if it doesn't exist
    if (!global._videoTasks) {
      global._videoTasks = new Map();
    }

    // Create initial task state
    const task = {
      imageUrl,
      status: "processing",
      progress: 0,
      startTime: Date.now(),
      frames: [],
      error: null,
    };

    global._videoTasks.set(taskId, task);

    // Start the frame generation process
    try {
      // Generate first frame to validate the process works
      const prompt = `Create a cinematic frame based on this reference image: ${imageUrl}. Make it photorealistic and high quality.`;
      const encodedPrompt = encodeURIComponent(prompt);
      const url = `/integrations/stable-diffusion-v-3/?prompt=${encodedPrompt}&width=512&height=512`;

      console.log("Testing frame generation with URL:", url);
      const response = await fetch(url);

      if (!response.ok) {
        throw new Error(
          `Stable Diffusion API error: ${response.status} ${response.statusText}`
        );
      }

      const data = await response.json();
      if (!data.data?.[0]) {
        throw new Error("No image URL returned from Stable Diffusion");
      }

      // If we get here, the first frame worked, so we can start the background process
      generateVideoFrames(taskId, imageUrl).catch((error) => {
        console.error("Error in background process:", error);
        const failedTask = global._videoTasks.get(taskId);
        if (failedTask) {
          failedTask.status = "failed";
          failedTask.error = error.message;
          global._videoTasks.set(taskId, failedTask);
        }
      });

      return {
        taskId,
        status: "processing",
        message: "Video generation started successfully",
      };
    } catch (error) {
      console.error("Error testing frame generation:", error);
      const task = global._videoTasks.get(taskId);
      if (task) {
        task.status = "failed";
        task.error = error.message;
        global._videoTasks.set(taskId, task);
      }
      return { error: `Failed to generate test frame: ${error.message}` };
    }
  } catch (error) {
    console.error("Error starting video generation:", error);
    return { error: error.message || "Failed to start video generation" };
  }
}

async function generateVideoFrames(taskId, imageUrl) {
  try {
    const task = global._videoTasks.get(taskId);
    if (!task) {
      throw new Error("Task not found: " + taskId);
    }

    console.log("Starting frame generation for task:", taskId);

    // Generate 5 frames
    const totalFrames = 5;
    const framePrompts = [
      "Create a cinematic frame that starts the transition, incorporating elements from the reference image.",
      "Generate a frame that shows a smooth progression from the previous frame, maintaining visual continuity.",
      "Design a frame that represents the middle point of the transition, balancing original and new elements.",
      "Create a frame that continues the transition, showing clear progression towards the final state.",
      "Generate the final frame that completes the transition while maintaining connection to the original image.",
    ];

    for (let i = 0; i < totalFrames; i++) {
      // Update progress
      const currentProgress = Math.round((i / totalFrames) * 100);
      task.progress = currentProgress;
      global._videoTasks.set(taskId, { ...task });
      console.log(
        `Task ${taskId}: Starting frame ${
          i + 1
        }/${totalFrames}, progress: ${currentProgress}%`
      );

      const prompt = `${framePrompts[i]} Reference image: ${imageUrl}. Frame ${
        i + 1
      } of ${totalFrames}. Make it photorealistic and high quality.`;
      console.log(`Task ${taskId}: Using prompt:`, prompt);

      try {
        // Encode the prompt properly
        const encodedPrompt = encodeURIComponent(prompt);
        const url = `/integrations/stable-diffusion-v-3/?prompt=${encodedPrompt}&width=512&height=512`;
        console.log(`Task ${taskId}: Calling Stable Diffusion:`, url);

        const response = await fetch(url);
        console.log(
          `Task ${taskId}: Got response:`,
          response.status,
          response.statusText
        );

        if (!response.ok) {
          throw new Error(
            `Failed to generate frame ${i + 1}: ${response.status} ${
              response.statusText
            }`
          );
        }

        const data = await response.json();
        console.log(`Task ${taskId}: Got data:`, data);

        if (!data.data?.[0]) {
          throw new Error(`No image URL returned for frame ${i + 1}`);
        }

        // Store the frame
        task.frames.push(data.data[0]);
        task.videoUrl = data.data[0]; // Show latest frame
        global._videoTasks.set(taskId, { ...task });
        console.log(`Task ${taskId}: Generated frame ${i + 1}/${totalFrames}`);

        // Small delay between frames to avoid rate limiting
        await new Promise((resolve) => setTimeout(resolve, 3000));
      } catch (frameError) {
        console.error(`Error generating frame ${i + 1}:`, frameError);
        throw frameError; // Let's fail fast if we can't generate a frame
      }
    }

    // Mark as completed
    task.status = "completed";
    task.progress = 100;
    task.videoUrl = task.frames[task.frames.length - 1];
    global._videoTasks.set(taskId, task);
    console.log(
      `Task ${taskId}: Completed successfully with ${task.frames.length} frames`
    );
  } catch (error) {
    console.error(`Task ${taskId}: Failed:`, error);
    const task = global._videoTasks.get(taskId);
    if (task) {
      task.status = "failed";
      task.error = error.message;
      global._videoTasks.set(taskId, task);
    }
    throw error;
  }
}
export async function POST(request) {
  return handler(await request.json());
}