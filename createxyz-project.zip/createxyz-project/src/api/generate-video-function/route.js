const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function handler({
  input_text = "Hello world",
  avatar_id = "Daisy-inskirt-20220818",
  voice_id = "2d5b0e6cf36f460aa7fc47e3eee4ba54",
  background_color = "#008000",
  width = 1280,
  height = 720,
  poll_interval = 60000,
}) {
  const videoPayload = {
    video_inputs: [
      {
        character: {
          type: "avatar",
          avatar_id,
          avatar_style: "normal",
        },
        voice: {
          type: "text",
          input_text,
          voice_id,
        },
        background: {
          type: "color",
          value: background_color,
        },
      },
    ],
    dimension: {
      width,
      height,
    },
  };

  try {
    const generateResponse = await fetch(
      "https://api.heygen.com/v2/video/generate",
      {
        method: "POST",
        headers: {
          "X-Api-Key": process.env.HEYGEN_API_KEY,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(videoPayload),
      }
    );

    if (!generateResponse.ok) {
      throw new Error(
        `Video creation failed with status ${generateResponse.status}`
      );
    }

    const createData = await generateResponse.json();
    const videoId = createData.data?.video_id;

    if (!videoId) {
      throw new Error("Video ID not found in the creation response");
    }

    return {
      success: true,
      data: {
        video_id: videoId,
      },
    };
  } catch (error) {
    return {
      success: false,
      error: error.message || "Failed to generate video",
    };
  }
}
export async function POST(request) {
  return handler(await request.json());
}