"use client";
import React from "react";



export default function Index() {
  return (function MainComponent({ initialMessage = "" }) {
  const [message, setMessage] = useState(initialMessage);
  const [avatarId, setAvatarId] = useState("Daisy-inskirt-20220818");
  const [voiceId, setVoiceId] = useState("2d5b0e6cf36f460aa7fc47e3eee4ba54");
  const [backgroundColor, setBackgroundColor] = useState("#008000");
  const [width, setWidth] = useState(1280);
  const [height, setHeight] = useState(720);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [videoId, setVideoId] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null);
  const [status, setStatus] = useState("");
  const [attempts, setAttempts] = useState(0);
  const MAX_ATTEMPTS = 10;

  const generateVideo = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/generate-video-function", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          input_text: message,
          avatar_id: avatarId,
          voice_id: voiceId,
          background_color: backgroundColor,
          width: parseInt(width),
          height: parseInt(height),
        }),
      });

      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error || "Failed to generate video");
      }

      setVideoId(data.data.video_id);
      setAttempts(0);
      startPolling(data.data.video_id);
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const startPolling = useCallback(
    (id) => {
      const pollInterval = setInterval(async () => {
        try {
          if (attempts >= MAX_ATTEMPTS) {
            setError("Timeout: Video generation took too long");
            setLoading(false);
            clearInterval(pollInterval);
            return;
          }

          const response = await fetch("/api/check-video-status", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ videoId: id }),
          });

          if (!response.ok) {
            throw new Error(`Error checking status: ${response.status}`);
          }

          const data = await response.json();
          if (!data.success) {
            throw new Error(data.error || "Failed to check video status");
          }

          setStatus(data.data.status);
          setAttempts((prev) => prev + 1);

          if (data.data.status === "completed") {
            setVideoUrl(data.data.video_url);
            setLoading(false);
            clearInterval(pollInterval);
          } else if (data.data.status === "failed") {
            throw new Error("Video generation failed");
          }
        } catch (err) {
          setError(err.message);
          setLoading(false);
          clearInterval(pollInterval);
        }
      }, 30000);

      return () => clearInterval(pollInterval);
    },
    [attempts],
  );

  return (
    <div className="max-w-lg mx-auto p-6 space-y-4">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Message
          </label>
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Enter your message"
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Avatar ID
          </label>
          <input
            type="text"
            value={avatarId}
            onChange={(e) => setAvatarId(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Voice ID
          </label>
          <input
            type="text"
            value={voiceId}
            onChange={(e) => setVoiceId(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            disabled={loading}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Background Color
          </label>
          <div className="flex space-x-2">
            <input
              type="color"
              value={backgroundColor}
              onChange={(e) => setBackgroundColor(e.target.value)}
              className="h-10 w-20"
              disabled={loading}
            />
            <input
              type="text"
              value={backgroundColor}
              onChange={(e) => setBackgroundColor(e.target.value)}
              className="flex-1 px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={loading}
            />
          </div>
        </div>

        <div className="flex space-x-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Width
            </label>
            <input
              type="number"
              value={width}
              onChange={(e) => setWidth(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={loading}
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Height
            </label>
            <input
              type="number"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              className="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={loading}
            />
          </div>
        </div>

        <button
          onClick={generateVideo}
          disabled={loading || !message}
          className="w-full px-4 py-2 text-white bg-blue-500 rounded-lg hover:bg-blue-600 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          {loading ? "Generating..." : "Generate Video"}
        </button>
      </div>

      {status && (
        <div className="text-sm text-gray-600 flex items-center space-x-2">
          <div
            className={`w-2 h-2 rounded-full ${status.toLowerCase() === "completed" ? "bg-green-500" : "bg-blue-500 animate-pulse"}`}
          />
          <span>
            {status.toLowerCase() === "completed" ? "Complete" : "Processing"}
            {loading && ` (Attempt ${attempts}/${MAX_ATTEMPTS})`}
          </span>
        </div>
      )}

      {error && <div className="text-sm text-red-500">{error}</div>}

      {videoUrl && (
        <div className="space-y-4">
          <video
            controls
            className="w-full rounded-lg shadow-lg"
            src={videoUrl}
          >
            Your browser does not support the video tag.
          </video>

          <div className="text-sm text-blue-500">
            <div className="font-medium mb-1">Video URL:</div>
            <a
              href={videoUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:underline break-all"
            >
              {videoUrl}
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="p-4">
      <div className="mb-8">
        <h2 className="text-lg font-medium mb-4">Default State</h2>
        <MainComponent />
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-medium mb-4">With Initial Message</h2>
        <MainComponent initialMessage="Hello, this is a test message!" />
      </div>
    </div>
  );
});
}